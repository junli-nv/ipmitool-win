#!/bin/bash

wget -c https://github.com/intel/mpi-benchmarks/archive/refs/tags/IMB-v2021.10.tar.gz
tar xzvf IMB-v2021.10.tar.gz
cd mpi-benchmarks-IMB-v2021.10

topdir=/home/cmsupport/workspace
source ${topdir}/hpcx-v2.25.1-gcc-doca_ofed-ubuntu24.04-cuda12-x86_64/hpcx-mt-init-ompi.sh
hpcx_load

CC=mpicc CXX=mpicxx make IMB-MPI1
