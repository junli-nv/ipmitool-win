#!/bin/bash
main(){
i=$1
nprocess=$(cat $i|awk '/# List of Benchmarks to run/,/# All processes entering MPI_Finalize/{print $0}'|grep -o '#processes.*' | awk '{print $3}')
cat $i|awk '/# List of Benchmarks to run/,/# All processes entering MPI_Finalize/{print $0}'|grep -Eo '(1048576|2097152|4194304).*' \
| awk -v nprocess=$nprocess -v rank_per_node=8 -v file=$i '
{
printf "%-30s%-30d%-30d%-30.1f\n", file, nprocess/rank_per_node,$1,$3/rank_per_node/1024/(nprocess/rank_per_node)*2
}
'
}
printf "%-30s%-30s%-30s%-30s\n" "FILENAME" "Node number" "MessageSize(bytes)" "per Rail BW(GB/s)"
for i in "$@"; do
  main $i
done

## ./log_parser.sh slurm-22*
#FILENAME                      Node number                   MessageSize(bytes)            per Rail BW(GB/s)
#slurm-2269.out                2                             1048576                       101.2
#slurm-2269.out                2                             2097152                       102.3
#slurm-2269.out                2                             4194304                       102.8
#slurm-2270.out                4                             1048576                       101.2
#slurm-2270.out                4                             2097152                       102.3
#slurm-2270.out                4                             4194304                       102.8
#slurm-2271.out                8                             1048576                       101.3
#slurm-2271.out                8                             2097152                       102.2
#slurm-2271.out                8                             4194304                       102.8
#slurm-2272.out                16                            1048576                       101.3
#slurm-2272.out                16                            2097152                       102.3
#slurm-2272.out                16                            4194304                       102.8
#slurm-2273.out                20                            1048576                       100.9
#slurm-2273.out                20                            2097152                       102.3
#slurm-2273.out                20                            4194304                       102.8
#slurm-2274.out                22                            1048576                       100.9
#slurm-2274.out                22                            2097152                       101.9
#slurm-2274.out                22                            4194304                       102.8