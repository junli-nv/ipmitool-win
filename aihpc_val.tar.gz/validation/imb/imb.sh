#!/bin/bash
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --time=10:00
#SBATCH -N 1
#SBATCH -x aic-gb3a-310004,aic-gb3a-310010

module load slurm
cd ${SLURM_SUBMIT_DIR}

topdir=/home/cmsupport/workspace

source ${topdir}/hpcx-v2.25.1-gcc-doca_ofed-ubuntu24.04-cuda12-x86_64/hpcx-mt-init-ompi.sh
hpcx_load

echo "NODELIST=$SLURM_JOB_NODELIST"
hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))
export SLURM_CPU_BIND=none

pdsh -f 100 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'
for i in $(grep ACTIVE /sys/class/infiniband/*/ports/1/state|cut -f5 -d'/'); do mlxlink -d ${i} -p 1 --pc &>/dev/null; done
EOF

set -x
ldd ${topdir}/imb/IMB-MPI1
mpirun --allow-run-as-root \
  --mca pml ucx --mca coll ^hcoll --mca btl ^openib,smcuda \
  --mca btl_tcp_if_include bond0 \
  --mca oob_tcp_if_include bond0 \
  --map-by ppr:4:socket:PE=16 \
  --display-map --display-topo --report-bindings \
  -x PATH=$PATH \
  -x LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
  -x OMPI_MCA_btl_openib_warn_default_gid_prefix=0 \
  -x OMPI_MCA_coll_hcoll_enable=0 \
  -x SLURM_CPU_BIND=none \
  -x OMPI_MCA_pml=ucx \
  -x UCX_TLS=rc_x \
\
  -H $(for i in ${hosts[*]}; do echo ${i}:8; done|paste -s -d ',') \
  -np $[8*${#hosts[*]}] \
  bash ${topdir}/imb/imb-wrapper.sh \
  ${topdir}/imb/IMB-MPI1 \
    -iter 100 -iter_policy off -time 30 \
    -npmin $[8*${#hosts[*]}] -mem 2 -msglog 20:22 \
    Biband
set +x

pdsh -f 100 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF' | sort &> /tmp/roce_pause.log
for i in $(grep ACTIVE /sys/class/infiniband/*/ports/1/state|cut -f5 -d'/'|grep -v bond); do ifdev=$(ls -1 /sys/class/infiniband/${i}/device/net/); ret=($(mlxlink -d ${i} -c 2>/dev/null|grep -E 'Effective Physical Errors|Link Down Counter'|awk '{print $NF}')); echo $i,$(ethtool -S $ifdev 2>/dev/null|grep -E 'rx_prio3_pause:|tx_prio3_pause:|rx_prio3_discards:'|tr -d ' '|paste -s -d ','),link_downed:${ret[1]},effective_error:${ret[0]},roce_adp_retrans:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/roce_adp_retrans 2>/dev/null),np_cnp_sent:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/np_cnp_sent 2>/dev/null),rp_cnp_handled:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/rp_cnp_handled 2>/dev/null); done
EOF
cat /tmp/roce_pause.log | grep ',rx_prio3_pause' |grep -E 'pause:[1-9][^,]*,|roce_adp_retrans:[1-9][^,]*,'|sort -t':' -n -k4
