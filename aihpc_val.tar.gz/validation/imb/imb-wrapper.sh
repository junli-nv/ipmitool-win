#!/bin/bash
ulimit -s unlimited
[ -n "${OMPI_COMM_WORLD_RANK}" ] && PMI_RANK=${OMPI_COMM_WORLD_RANK} && MPI_LOCALRANKID=${OMPI_COMM_WORLD_LOCAL_RANK}

export UCX_MAX_EAGER_LANES=8
export UCX_MAX_RNDV_LANES=8
export UCX_MAX_RMA_LANES=8
export UCX_PROTO_ENABLE=y
export UCX_RNDV_SCHEME=get_zcopy   # or put_zcopy, but get_zcopy is often safer
export UCX_MAX_EAGER_RAILS=2
export UCX_MAX_RNDV_RAILS=2
export UCX_IB_GID_INDEX=3

case $MPI_LOCALRANKID in
0) export UCX_NET_DEVICES="roce_p0_rail0:1,roce_p1_rail0:1" ;;
1) export UCX_NET_DEVICES="roce_p0_rail1:1,roce_p1_rail1:1" ;;
2) export UCX_NET_DEVICES="roce_p0_rail2:1,roce_p1_rail2:1" ;;
3) export UCX_NET_DEVICES="roce_p0_rail3:1,roce_p1_rail3:1" ;;
4) export UCX_NET_DEVICES="roce_p0_rail4:1,roce_p1_rail4:1" ;;
5) export UCX_NET_DEVICES="roce_p0_rail5:1,roce_p1_rail5:1" ;;
6) export UCX_NET_DEVICES="roce_p0_rail6:1,roce_p1_rail6:1" ;;
7) export UCX_NET_DEVICES="roce_p0_rail7:1,roce_p1_rail7:1" ;;
esac
cmd="numactl -l $@"
echo "HOST=$(hostname), RANK=${PMI_RANK}, LOCALRANK=${MPI_LOCALRANKID}, UCX_NET_DEVICES=${UCX_NET_DEVICES}, CMD=${cmd}, PID=$$ AFF=$(taskset -pc $$)"
eval ${cmd}
