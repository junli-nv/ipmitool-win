#!/bin/bash

## https://apps.nvidia.com/PID/ContentLibraries/Detail/1127062
cd /home/cmsupport/workspace/629-24972-4975-FLD-50898-rev23

# cmsh -c 'rack list'
rack=GB200-Rack2
BCM_HEADNODE_IP=10.135.8.2
nodes=($(cmsh -c "device list -r ${rack}"|grep PhysicalNode|awk '{print $2}'))

# Check the compute nodes shipped with original connectors
pdsh -R ssh -w $(echo ${nodes[*]}|tr ' ' ',') <<- EOF | dshbak -c
dmidecode | grep -e 699-2G548-1201-A00 -e 699-2G548-1201-A10 -e 699-2G548-1201-800 -e 699-2G548-0202-800 -e 699-2G548-0202-A00
EOF

# Stop services and split bonded interfaces on compute trays
pdcp -R ssh -w $(echo ${nodes[*]}|tr ' ' ',') ./prepnode.sh /tmp/prepnode.sh
pdsh -R ssh -w $(echo ${nodes[*]}|tr ' ' ',') <<- EOF
bash /tmp/prepnode.sh || true
EOF

# Change the compute tray root password to "Nvidia@123" beforehand in temp
pdsh -R ssh -w $(echo ${nodes[*]}|tr ' ' ',') <<- EOF
echo 'root:Nvidia@123' | chpasswd
EOF

bash gen-config.sh ${rack} > ${rack}.json
netstat -anp|grep 15650
netstat -anp|grep $(cat ${rack}.json|jq '.global_args.cluster_cfg.gdm_port')
pkill -9 python3

## If you want to run multiple racks concurrently:
# Use different run directories per rack (separate working dirs and logs)
# Ensure each rack uses a unique gdm_port to prevent collisions
## Important: bonded interfaces are not supported for the GDM implementation in Partner Diags
# This includes the node from which you’re launching the partner diags and the compute nodes.
# Partner diags GDM code will not work on bonded interfaces.
# Use a non-bonded interface/IP for --primary_diag_ip
# Reference: NVBug 5679837: https://nvbugspro.nvidia.com/bug/5679837

## In this case, head node has bonded interfaces, but compute trays don't have. Then add loopback_ip help.
## But if all nodes have bonded interfaces, then will fail to run.
./partnerdiag --mfg --run_spec=${rack}.json \
  --primary_diag_ip=${BCM_HEADNODE_IP} \
  --topology=topo_72x1.json --test=NvlGpuStress --no_bmc \
  --loopback_ip=127.0.0.1 2>&1 | tee ${rack}-output.txt

grep 'Final Result:' partnerdiag.log
grep -e 'NvlGpuStress.*NVLink.*Error Threshold Exceeded' -e 'NETIR_LINK_EVT.*Fatal' run.log
