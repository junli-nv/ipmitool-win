#!/bin/bash
#
for i in {0..3}; do
sbatch -N 1 -o root-NEMO-LLAMA3_8B-1N-%N-%j.txt nemo-llma3_8b.sh
done
sbatch -N 2 -o root-NEMO-NEMOTRON5H_56B-2N-%N-%j.txt nemo-nemotron5h_56b-mbridge-fp8.sh
sbatch -N 4 -o root-NEMO-NEMOTRON5H_56B-4N-%N-%j.txt nemo-nemotron5h_56b-mbridge-fp8.sh
