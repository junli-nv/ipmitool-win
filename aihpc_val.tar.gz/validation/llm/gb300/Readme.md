## Performance of GB300(up to 2 racks)
For each compute tray: 2x72C Neoverse-V2, 2x480GB Mem, 4xGB300, 1xdual port BlueField3 B3240 400GbE, 4xCx8 C8280Z 800Gb IB

All the logs can be found at:
https://nvidia-my.sharepoint.com/:f:/p/junliz/IgAt0FT-hHh-RJ_pr1jtyM4IAWUY4X4AF4kt7AWUJHvI3tE?e=6BdIDd

### **LLAMA3 8B(FP8 CS)**
LLAMA3 8B can work well with any number of GB300 nodes and the scaling efficiency is good.
```
                   root-NEMO-LLAMA3_8B-1N.2288.txt: Step[s]=3.36 perGPU[TFLOPs]=2008.20 Sstd=0.01307 Pstd=7.86464 MFU=40.2% 
                   root-NEMO-LLAMA3_8B-1N.2289.txt: Step[s]=3.37 perGPU[TFLOPs]=2003.20 Sstd=0.01325 Pstd=7.89803 MFU=40.1% 
                   root-NEMO-LLAMA3_8B-1N.2290.txt: Step[s]=3.38 perGPU[TFLOPs]=1998.60 Sstd=0.01061 Pstd=6.19338 MFU=40.0% 
                   root-NEMO-LLAMA3_8B-1N.2291.txt: Step[s]=3.34 perGPU[TFLOPs]=2019.85 Sstd=0.01293 Pstd=7.81547 MFU=40.4% 
                  root-NEMO-LLAMA3_8B-17N-2372.txt: Step[s]=3.38 perGPU[TFLOPs]=1998.00 Sstd=0.00445 Pstd=2.57519 MFU=40.0% 
                  root-NEMO-LLAMA3_8B-36N-2501.txt: Step[s]=3.38 perGPU[TFLOPs]=1994.20 Sstd=0.00369 Pstd=2.30788 MFU=39.9% 
```
LLAMA3 8B highly depends on NCCL Allreduce performance. NCCL multiple racks allreduce performance should around 800GB/s.
```
root-NEMO-LLAMA3_8B-1N.2288.txt: 677.75
root-NEMO-LLAMA3_8B-1N.2289.txt: 682.37
root-NEMO-LLAMA3_8B-1N.2290.txt: 686.66
root-NEMO-LLAMA3_8B-1N.2291.txt: 677.25
root-NEMO-LLAMA3_8B-17N-2372.txt: 924.55
root-NEMO-LLAMA3_8B-36N-2501.txt: 805.36
```

### **Nemotron5H 56B(FP8 CS)**
Nemotron5H 56B needs at least two GB300 nodes and should scale with times of 2. The scaling efficiency is good.
```
              root-NEMO-NEMOTRON5H_56B-2N.2292.txt: Step[s]=4.41 perGPU[TFLOPs]=1869.28 Sstd=0.00768 Pstd=2.91107 MFU=37.4% 
              root-NEMO-NEMOTRON5H_56B-4N.2293.txt: Step[s]=4.38 perGPU[TFLOPs]=1880.57 Sstd=0.00470 Pstd=2.33060 MFU=37.6% 
             root-NEMO-NEMOTRON5H_56B-16N-2336.txt: Step[s]=4.39 perGPU[TFLOPs]=1879.87 Sstd=0.01099 Pstd=4.42351 MFU=37.6% 
             root-NEMO-NEMOTRON5H_56B-36N-2502.txt: Step[s]=4.39 perGPU[TFLOPs]=1877.83 Sstd=0.00951 Pstd=3.58833 MFU=37.6% 
```
Nemotron5H 56B highly depends on NCCL Allreduce performance. NCCL multiple racks allreduce performance should around 800GB/s.
```
root-NEMO-NEMOTRON5H_56B-2N.2292.txt: 839.43
root-NEMO-NEMOTRON5H_56B-4N.2293.txt: 915.66
root-NEMO-NEMOTRON5H_56B-16N-2336.txt: 934.91
root-NEMO-NEMOTRON5H_56B-36N-2502.txt: 806.97
```

### **Nemotron4 340B(BF16)**
Nemotron4 340B needs at least 16 GB300 nodes and should scale with times of 16. The scaling efficiency is good.
```
  root-NEMO-NEMOTRON4_340B-16N-1Rack-wiIB-2365.txt: Step[s]=1.66 perGPU[TFLOPs]=1269.90 Sstd=0.00097 Pstd=0.55251 MFU=25.4% 
  root-NEMO-NEMOTRON4_340B-16N-1Rack-woIB-2371.txt: Step[s]=1.66 perGPU[TFLOPs]=1269.90 Sstd=0.00159 Pstd=1.07115 MFU=25.4%
       root-NEMO-NEMOTRON4_340B-32N-2Rack-2505.txt: Step[s]=1.72 perGPU[TFLOPs]=1227.65 Sstd=0.00122 Pstd=0.74516 MFU=24.6% 
```
Nemotron4 340B highly depends on NCCL Allreduce performance. NCCL multiple racks allreduce performance should around 800GB/s.
```
root-NEMO-NEMOTRON4_340B-16N-1Rack-wiIB-2365.txt: 929.91
root-NEMO-NEMOTRON4_340B-16N-1Rack-woIB-2371.txt: 930.10
root-NEMO-NEMOTRON4_340B-32N-2Rack-2505.txt: 801.77
```

### **Deepseek V3 671B(FP8 MX)**
Deepseek V3 671B needs at least 32 GB300 nodes. 
**HCA down or flapping will affect the overall performance a lot.**
```
                 root-NEMO-DEEPSEEKV3-32N-2622.txt: Step[s]=8.03 perGPU[TFLOPs]=1061.25 Sstd=0.00733 Pstd=0.93499 MFU=21.2%
                 root-NEMO-DEEPSEEKV3-32N-2623.txt: Step[s]=8.02 perGPU[TFLOPs]=1061.62 Sstd=0.00686 Pstd=1.00414 MFU=21.2%
```
Deepseek V3 671B highly depends on NCCL Alltoall performance. NCCL multiple racks Alltoall performance should around 96GB/s.
```
root-NEMO-DEEPSEEKV3-32N-2622.txt: 96.37
root-NEMO-DEEPSEEKV3-32N-2623.txt: 97.60
```

## Coherent GPU Memory Mode(CDMM)
By default, GPU memory shown as NUMA nodes. After copy, uncompress lots of or quite big files, the GPU memory may be occupied by OS page cache which will make the big LLM model like deepseek v3 failed to run. 
The temporary workaround is monitor the GPU memory usage and drop page cache before run the large model. 
The final solution is enable CDMM instead. 
```
root@b06-p01-dgx-06-c16:~# nvidia-smi | grep Default | awk -F'|' '{print $4}'|paste - - - -
335MiB / 284208MiB       10MiB / 284208MiB       10MiB / 284208MiB       54837MiB / 284208MiB
root@b06-p01-dgx-06-c16:~# echo 3 > /proc/sys/vm/drop_caches 
root@b06-p01-dgx-06-c16:~# nvidia-smi | grep Default | awk -F'|' '{print $4}'|paste - - - -
104MiB / 284208MiB        9MiB / 284208MiB       8MiB / 284208MiB       141MiB / 284208MiB
```
Workaround: offline the numa node on fly(can't make sure 100% work)
```
echo 3 > /proc/sys/vm/drop_caches 
cd /sys/devices/system/memory
ls -l memory*/node*|grep -v -e '/node0 ' -e '/node1 '|awk '{print $(NF-2)}'|cut -f 1 -d'/'|sort|uniq|while read i; do echo 0 > $i/online; done
```