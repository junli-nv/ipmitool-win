#!/bin/bash
# Mainterner: Junli Zhang<junliz@nvidia.com>

## Method1: Using Enroot container to download the model
mkdir -p /local/enroot/{data,runtime}
export ENROOT_DATA_PATH=/local/enroot/data/$(id -u)
export ENROOT_RUNTIME_PATH=/local/enroot/runtime/$(id -u)
enroot remove -f nemo
enroot create -n nemo /local/nemo/nemo-25.11.01.sqsh
enroot list -f
mkdir -p /local/nemo/huggingface
enroot start -w -e HF_TOKEN=$YOUR_HF_TOKEN -m /local/nemo:/local/nemo nemo \
bash <<- '__END__'
export HF_HOME=/local/nemo/huggingface/
mv /root/.cache/huggingface/* $HF_HOME/
hf auth login --token $HF_TOKEN --add-to-git-credential
hf auth list
export HF_HUB_OFFLINE=0
## Download DeepSeek-V3-Base model from Hugging Face
#-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3-Base
hf download --repo-type model deepseek-ai/DeepSeek-V3-Base
cd ${HF_HOME}/hub && ln -sf models--deepseek-ai--DeepSeek-V3-Base models--deepseek-ai--DeepSeek-V3
__END__
cd /local/nemo/
mksquashfs huggingface huggingface.squashfs

## Method2: download the model on bare metal
apt install -y python3.12-venv
python3.12 -mvenv venv
source venv/bin/activate
pip install hf
cd /local/nemo/
export HF_HOME=$PWD/huggingface
hf auth login --token $HF_TOKEN --add-to-git-credential
hf auth list
export HF_HUB_OFFLINE=0
hf download --repo-type model deepseek-ai/DeepSeek-V3-Base
cd ${HF_HOME}/hub && ln -sf models--deepseek-ai--DeepSeek-V3-Base models--deepseek-ai--DeepSeek-V3
hf auth logout
mksquashfs huggingface huggingface.squashfs
deactivate
