#!/bin/bash

declare -A perf
perf[gb300]=5000
perf[gb200]=4900
perf[b200]=4500
perf[h00]=1979

gpu=gb300

log_files=($@)

log_parser(){
  if [ $(grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|wc -l) -gt 0 ]; then
    grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g' \
      | awk -v min_iter=70 -v max_iter=90 -v fname=$1 -v perf=${perf[${gpu}]} '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$8; ps+=$8;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)
    printf "%50s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f MFU=%.1f%% \n", fname, ts/ct, ps/ct, t_std, p_std, ps/ct/perf*100
  }
}
'
  else
    grep -o 'train_step_timing.*consumed_samples' $1|tr '|' ' ' \
      | awk -v min_iter=70 -v max_iter=90 -v fname=$1 -v perf=${perf[${gpu}]} '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$6; ps+=$6;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)
    printf "%50s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f MFU=%.1f%% \n", fname, ts/ct, ps/ct, t_std, p_std, ps/ct/perf*100
  }
}
'
  fi
}
for i in ${log_files[@]}; do
 log_parser $i
done
