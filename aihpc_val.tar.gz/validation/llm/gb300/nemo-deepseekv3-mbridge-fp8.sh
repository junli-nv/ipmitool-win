#!/bin/bash
# Mainterner: Junli Zhang<junliz@nvidia.com>
#
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=36
#SBATCH --gpus-per-node=4
#SBATCH --time=00:30:00
#SBATCH -N 32

CONT=/lustre/nemo/nemo-25.11.01.sqsh

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash $PWD/sysinfo.sh 2>&1

set -x
ns_nic=enP22p3s0f0np0
ew_nics=($(echo mlx5_{0..3}))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp
#export NCCL_IB_DISABLE=1
#export UCX_NET_DEVICES=${ns_nic}
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"

export NCCL_SOCKET_IFNAME=${ns_nic}
export OMPI_MCA_btl_tcp_if_include=${ns_nic}
export OMPI_MCA_oob_tcp_if_include=${ns_nic}
export NVTE_UB_SOCKET_IFNAME=${ns_nic}
export GLOO_SOCKET_IFNAME=${ns_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none
#
export NCCL_P2P_LEVEL=NVL
export NCCL_NVLS_ENABLE=1
export NCCL_CUMEM_ENABLE=1
export NCCL_MIN_CTAS=16
export NCCL_MNNVL_ENABLE=1
export NCCL_DEBUG=INFO

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

## test nccl
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
alltoall_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

############ Nemo Run ############
#nodes=( $( scontrol show hostnames $SLURM_JOB_NODELIST ) )
#nodes_array=($nodes)
#head_node=${nodes_array[0]}
#head_node_ip=$(srun --nodes=1 --ntasks=1 -w "$head_node" hostname --ip-address)

srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev,/local/nemo/huggingface:/root/.cache/huggingface \
bash <<- '__END__'
set -ex
export PYTHONUNBUFFERED=1
export SLURM_UNBUFFEREDIO=1
export TORCHX_MAX_RETRIES=0

export HF_HUB_OFFLINE=1
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64

export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export TORCH_NCCL_HIGH_PRIORITY=1
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=20
export NVTE_BWD_LAYERNORM_SM_MARGIN=20
export NVLINK_DOMAIN_SIZE=72

export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}/experiments
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH

export NCCL_DEBUG=WARN
export NCCL_NVLS_ENABLE=0  ##NVLS led OOM, disable it for safe.

#### TP/PP/CP/EP/VP tunning -> https://docs.nvidia.com/nemo-framework/user-guide/latest/performance/performance-guide.html
#
## Rule: 
#1. num_gpus % (tp * pp * cp) = 0
#2. dp=$[num_gpus/(tp*pp*cp)]
#3. ga=$[gb/(mb*dp)] 
#4. num_moe_experts(256) % (ep * etp) = 0
#5. ep * etp <= dp * cp * tp
#6. expert_tensor_model_pipeline_parallel_size=(tp*pp*cp)*(ep*etp) <= num_gpus
#7. ep <= NVLINK_DOMAIN_SIZE. ep and tp kept within NVLink domain where possible; larger ep reduces per GPU expert memory and can help with CG.
#
#TODO: 
# tokendrop Workaround: disable moe_flex_dispatcher_backend when using "--use_tokendrop 1".
# sed -i -e 's:moe_flex_dispatcher_backend=.*:moe_flex_dispatcher_backend=None,:g' /opt/Megatron-Bridge/scripts/performance/configs/deepseek/workload_base_configs.py
#
numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --num_gpus $[4*${SLURM_NNODES}] \
  --gpus_per_node 4 \
  --compute_dtype fp8_mx \
  --model_name deepseek --model_size v3 \
  --use_megatron_fsdp 0 \
  -tp 1 \
  -pp 4 \
  -cp 1 \
  -ep 32 \
  -vp 4 \
  -et 1 \
  -mb 1 \
  -gb $[512*${SLURM_NNODES}/16] \
  --max_steps 110 \
  train.manual_gc=true train.manual_gc_interval=100 \
  --recompute_modules moe_act --cuda_graph_impl transformer_engine --cuda_graph_scope attn \
  --gpu gb300
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"