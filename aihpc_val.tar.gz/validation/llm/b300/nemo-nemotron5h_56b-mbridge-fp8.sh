#!/bin/bash
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH --time=00:30:00
#SBATCH -N 1

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
pdsh -t 3 -u 3 -R ssh -f 36 -w $SLURM_NODELIST  <<- 'EOF' | dshbak -c
nvidia-smi -L|wc -l
nvidia-smi nvlink -s|grep [0-9].*GB|wc -l
ibstatus|grep -E 'Infiniband|state:'|paste - - -|grep roce|tr -s ' '
EOF

set -x
#ew_nics=($(echo roce_p{0,1}_rail{0..7}))
ew_nics=($(echo roce_p0_rail{0..7}))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp NCCL_IB_DISABLE=1
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
export NCCL_SOCKET_IFNAME=bond0
export OMPI_MCA_btl_tcp_if_include=bond0
export OMPI_MCA_oob_tcp_if_include=bond0
export NVTE_UB_SOCKET_IFNAME=bond0
export GLOO_SOCKET_IFNAME=bond0
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_TC=96
export NCCL_IB_ADAPTIVE_ROUTING=1
export NCCL_IB_SL=1
export NCCL_IB_QPS_PER_CONNECTION=8
export NCCL_IB_TC=96
export NCCL_IB_GID_INDEX=3
export NCCL_MIN_NCHANNELS=32
export NCCL_NVLS_ENABLE=1
export NCCL_P2P_LEVEL=NVL
export NCCL_MIN_CTAS=64
export SLURM_CPU_BIND=none

## generate config files
### Rule: num_gpus % (ep * et * tp * pp) == 0
#python3 /opt/Megatron-Bridge/scripts/performance/setup_experiment.py ... ... #the same args with run_script.py

# run nemo test
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
--container-mounts=/dev:/dev \
bash <<- '__END__'
set -ex
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HOME=/root/.cache/huggingface

export NEMORUN_HOME=/mnt/nemo
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export NCCL_NVLS_ENABLE=0
export NVTE_FLASH_ATTN=1
export NVTE_FUSED_ATTN=1
export CUDA_DEVICE_MAX_CONNECTIONS=1
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
export TORCH_NCCL_HIGH_PRIORITY=1
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
export NCCL_DEBUG=INFO

## Rule: num_gpus % (ep * et * tp * pp) == 0
#With CUDA graphs, then expandable segments must be disabled by "unset PYTORCH_CUDA_ALLOC_CONF".
#For arguments explanation, please refer to 
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/blob/main/scripts/performance/argument_parser.py
#For model name and model size, please refer to 
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/blob/main/scripts/performance/configs/nemotronh/nemotronh_workload_base_configs.py
numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu gb300 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --compute_dtype fp8_cs \
  --model_name nemotronh --model_size 56b \
  --use_megatron_fsdp 0 \
  -tp 2 \
  -pp 1 \
  -cp 1 \
  -ep 1 \
  -mb 1 \
  -gb $[192*${SLURM_NNODES}/8] \
  --cuda_graph_impl transformer_engine --cuda_graph_scope mamba,attn \
  --max_steps 110 \
  train.manual_gc=true train.manual_gc_interval=100
__END__

set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"
