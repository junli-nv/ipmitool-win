#!/bin/bash

log_files=($(ls root-NEMOTRON5H-*.txt|sort -t'-' -k3 -n))

log_parser(){
 grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g' \
   | awk -v min_iter=70 -v max_iter=90 -v fname=$1 '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$8; ps+=$8;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)
    printf "%30s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f \n", fname, ts/ct, ps/ct, t_std, p_std
  }
}
'
}
for i in ${log_files[@]}; do
 log_parser $i
done

## Sample output on B300(each node 8GPUs):
## ## Nemotron 5H-56B FP8 stress B300 quite well(>1000W per GPU, THMMA:0.3~0.5), and scales well from 1N to 23N.
#   root-NEMOTRON5H-2N-1390.txt: Step[s]=5.09 perGPU[TFLOPs]=1618.72 Sstd=0.01026 Pstd=3.08419
#   root-NEMOTRON5H-4N-1391.txt: Step[s]=5.09 perGPU[TFLOPs]=1618.71 Sstd=0.01436 Pstd=4.35236
#   root-NEMOTRON5H-8N-1392.txt: Step[s]=5.10 perGPU[TFLOPs]=1616.64 Sstd=0.01447 Pstd=4.57963
#  root-NEMOTRON5H-12N-1393.txt: Step[s]=5.10 perGPU[TFLOPs]=1616.67 Sstd=0.00813 Pstd=2.38523
#  root-NEMOTRON5H-16N-1394.txt: Step[s]=5.16 perGPU[TFLOPs]=1599.08 Sstd=0.01100 Pstd=3.23944
#  root-NEMOTRON5H-20N-1395.txt: Step[s]=5.17 perGPU[TFLOPs]=1595.00 Sstd=0.01182 Pstd=3.52293
#  root-NEMOTRON5H-23N-1396.txt: Step[s]=5.21 perGPU[TFLOPs]=1581.89 Sstd=0.01556 Pstd=4.78281

plot_file(){
  echo $1
  grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g'|awk '{print $8}' \
    | gnuplot -e "set term dumb size 300,50; set yrange [0:1800]; plot '-' with linespoints" 2>/dev/null
}
for i in ${log_files[@]}; do
 plot_file $i
done

plot_file_ts(){
  echo $1
  grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g'|awk '{print $4}' \
    | gnuplot -e "set term dumb size 300,50; set yrange [11:15]; set ytics 0.5; set xtics 5; set grid; plot '-' with linespoints" 2>/dev/null
}
