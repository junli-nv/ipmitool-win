#!/bin/bash

unset MELLANOX_VISIBLE_DEVICES ##<-- IMPORTANT, or nccl failed to run in nemo container
export NCCL_NVLS_ENABLE=1
export NCCL_DEBUG=INFO
export NCCL_P2P_LEVEL=NVL
export NCCL_MIN_CTAS=64
export NCCL_IB_DISABLE=1
export UCX_TLS=tcp
export NCCL_SOCKET_IFNAME=bond0
export UCX_NET_DEVICES=bond0
export PMIX_MCA_gds=hash

export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_tcp_if_include=bond0
export OMPI_MCA_oob_tcp_if_include=bond0

## Check NCCL whether can run properly
srun -p defq --exclusive --cpu-bind=none --mpi=pmix \
--ntasks-per-node=8 --cpus-per-task=32 --gpus-per-node=8 \
-N 1 -w aic-gb3a-310023 \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20

## Start an interactive session
srun -p defq --exclusive --cpu-bind=none --mpi=pmix \
--ntasks-per-node=8 --cpus-per-task=32 --gpus-per-node=8 \
-N 1 -w aic-gb3a-310023 \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
--container-mounts=/home/cmsupport/workspace:/home/cmsupport/workspace \
--container-writable \
--wait=$[12*3600] --kill-on-bad-exit=0 \
--pty bash

## Do tests inside the container

## run nccl again
mpirun -np 8 \
  all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20

## generate config files
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
cd /opt/NeMo
rm -f scripts/performance/recommended_model_configs/*.csv
export NEMORUN_HOME=/tmp/NeMoRuns
rm -rf ${NEMORUN_HOME}
mkdir -p ${NEMORUN_HOME}
GPUs=8
python -m scripts.performance.llm.pretrain_llama3_8b \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu b200 \
  --compute_dtype fp8 --fp8_recipe cs \
  --num_gpus ${GPUs} \
  -fsdp 0 \
  -tp 1 \
  -pp 1 \
  -cp 1 \
  -ep 1 \
  -mb 4 \
  -gb 128 \
  --gpus_per_node 8 \
  --max_steps 20000
CASE=$(find ${NEMORUN_HOME} -name '*_fn_or_script' | head -1)
ls -l ${CASE}

## run nemo with mpirun inside the container
mpirun \
  -x CPATH=/usr/local/cuda/include \
  -x TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas \
  -x TRITON_LIB_DIR=/usr/local/cuda/lib64 \
\
  -x TORCH_NCCL_AVOID_RECORD_STREAMS=1 \
  -x TRANSFORMERS_OFFLINE=1 \
  -x TOKENIZERS_PARALLELISM=False \
  -x NCCL_NVLS_ENABLE=0 \
  -x NVTE_FLASH_ATTN=1 \
  -x NVTE_FUSED_ATTN=1 \
  -x NEMO_LOG_MEMORY_USAGE=1 \
  -x NEMORUN_HOME=$PWD \
  -x NEMO_HOME=$PWD \
  -x CUDA_DEVICE_MAX_CONNECTIONS=32 \
  -x NVTE_FWD_LAYERNORM_SM_MARGIN=16 \
  -x NVTE_BWD_LAYERNORM_SM_MARGIN=16 \
  -x NCCL_P2P_NET_CHUNKSIZE=2097152 \
\
  -np 8 \
  python -m nemo_run.core.runners.fdl_runner -n $(basename ${CASE}|sed -e 's:_fn_or_script::g') ${CASE} 2>&1 | tee log.txt
