#!/bin/bash

## Configure squid proxy on bcm head node(10.36.201.200)
sed -i.ori "/acl localnet src fe80::\/10/aacl localnet src 10.36.201.0\/24" /etc/squid/squid.conf
systemctl start squid

mkdir -p /home/cmsupport/workspace/nemo/huggingface
srun -N 1 --ntasks-per-node=1 --gpus-per-node=1 \
--container-writable \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
--container-mounts=/home/cmsupport/workspace/nemo/huggingface:/nemo/huggingface \
bash <<- '__END__'
cp -ar /root/.cache/huggingface/* /nemo/huggingface/
export http_proxy=http://10.36.201.200:3128
export https_proxy=http://10.36.201.200:3128
export HF_HOME=/nemo/huggingface

hf auth login --token $YOUR_HF_TOKEN --add-to-git-credential
hf auth list
export HF_HUB_OFFLINE=0

## Download Qwen3-30B-A3B model from Hugging Face
#-> ${HF_HOME}/hub/models--Qwen--Qwen3-30B-A3B
hf download --repo-type model Qwen/Qwen3-30B-A3B

## Download DeepSeek-V3-Base model from Hugging Face
#-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3-Base
hf download --repo-type model deepseek-ai/DeepSeek-V3-Base

cd ${HF_HOME}/hub && ln -sf models--deepseek-ai--DeepSeek-V3-Base models--deepseek-ai--DeepSeek-V3

## Download DeepSeek-V3 model from Hugging Face
#-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3
#hf download --repo-type model deepseek-ai/DeepSeek-V3
__END__

## Download DeepSeek-V3-Base model from Hugging Face using python
#python3 <<- '_EOF_'
#from transformers import AutoModelForCausalLM
#model = AutoModelForCausalLM.from_pretrained(
#    "deepseek-ai/DeepSeek-V3-Base",
#    trust_remote_code=True,
#)
#_EOF_

## Clone DeepSeek-V3-Base model from Hugging Face
# cd /home/cmsupport/workspace/nemo/model
# sudo apt-get install -y git-lfs
# git lfs install
# git clone https://huggingface.co/deepseek-ai/DeepSeek-V3-Base

## Scatter huggingface cache to all nodes
cd /home/cmsupport/workspace/nemo
mksquashfs huggingface huggingface.squashfs
pdcp -R ssh -w ${NODELIST} <<- EOF
nohup cp /home/cmsupport/workspace/nemo/huggingface.squashfs /raid/nemo/ &>/dev/null &
EOF
#After copy work done, uncompress the huggingface.squashfs on each node
pdcp -R ssh -w ${NODELIST} <<- EOF
nohup unsquashfs -f -d /raid/nemo/huggingface /raid/nemo/huggingface.squashfs &>/dev/null &
EOF
