# Mainterner: Junli Zhang<junliz@nvidia.com>
  
## Update the container
srun -N 1 -p defq --exclusive --gpus-per-node=1 \
  --container-writable \
  --container-image /home/cmsupport/workspace/nemo-25.04.rc2.sqsh \
  --container-save /home/cmsupport/workspace/nemo-25.04.rc2.m2.sqsh \
  --container-mounts /dev/:/dev,/home/cmsupport/workspace:/home/cmsupport/workspace \
  --wait=120 --kill-on-bad-exit=0 --mpi=pmix \
  --pty bash

#Leave NVCC_GENCODE unset to support more GPU architectures
tar -xvf /home/cmsupport/workspace/nccl.tar.xz -C ./
cd nccl/
git checkout v2.28.3-1
make -j src.build
rm -f /usr/lib/x86_64-linux-gnu/libnccl*
cp build/lib/libnccl.so.2.28.3 /usr/lib/x86_64-linux-gnu/libnccl.so.2.28.3
cp build/lib/libnccl_static.a /usr/lib/x86_64-linux-gnu/libnccl_static.a
cd /usr/lib/x86_64-linux-gnu
ln -sf libnccl.so.2.28.3 libnccl.so.2
ln -sf libnccl.so.2 libnccl.so
ls -lh /usr/lib/x86_64-linux-gnu/libnccl*
cd -
cp ./build/include/nccl.h /usr/include/nccl.h
cp ./build/bin/ncclras /usr/bin/ncclras
cd nccl-tests
make -j MPI=1 NAME_SUFFIX=_mpi MPI_HOME=/usr/local/mpi NCCL_HOME=$PWD/../build
rm -f /usr/local/bin/*_perf*
cp build/*_mpi /usr/local/bin/
ls -lh /usr/local/bin/*_perf*
rm -rf build/
rm -rf ../build/

history -c
## Exit to save the container
exit 0

## Sign the new built container
md5sum /home/cmsupport/workspace/nemo-25.04.rc2.m2.sqsh > /home/cmsupport/workspace/nemo-25.04.rc2.m2.sqsh.md5sum
