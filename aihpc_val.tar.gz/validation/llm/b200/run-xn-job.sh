#!/bin/bash
# Mainterner: Junli Zhang<junliz@nvidia.com>

if [ $# -ne 2 ]; then
  echo "Usage: $(basename $0) step nodelist"
  exit 0
fi

step=$1
target_nodes=$2
all_hosts=($(scontrol show hostname ${target_nodes}))
#echo ${#all_hosts[*]} ${all_hosts[*]}
#
i=0; while [ $i -lt ${#all_hosts[*]} ]; do
  s0=$[i+1]
  s1=$[i+step]
  t_hosts=($(echo ${all_hosts[*]} ${all_hosts[*]}|cut -f${s0}-${s1} -d ' '))
  jobname=NEMOTRON4_340B-${#t_hosts[*]}N
  [ ${#t_hosts[*]} -eq 1 ] && file=${USER}-${jobname}-%N-%j.txt || file=${USER}-${jobname}-%j.txt
  #cat <<- EOF
  sbatch \
    -N ${#t_hosts[*]} \
    -w "$(echo ${t_hosts[*]}|tr ' ' ',')" \
    -t 1:00:00 \
    --job-name=${jobname} \
    --output=${file} \
    nemo-nemotron4_340b.sh
#EOF
  i=${s1}
done
