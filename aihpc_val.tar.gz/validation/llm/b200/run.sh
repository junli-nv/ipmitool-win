#!/bin/bash
# Mainterner: Junli Zhang<junliz@nvidia.com>

nodelist=dgx-3nd-02-[04,14,24,34],dgx-3nd-03-[04,14,24,34],dgx-3nd-04-[04,14,24,34],dgx-3nd-05-[04,14,24,34],dgx-3nd-06-[04,14,24,34],dgx-3nd-07-[04,14,24,34],dgx-3nd-08-[04,14,24,34],dgx-3nd-09-[04,14,24,34],dgx-3nd-14-[04,14,24,34],dgx-3nd-15-[04,14,24,34],dgx-3nd-16-[04,14,24,34],dgx-3nd-17-[04,14,24,34],dgx-3nd-18-[04,14,24,34],dgx-3nd-19-[04,14,24,34],dgx-3nd-20-[04,14,24,34],dgx-3nd-21-[04,14,24,34]
for i in 16 32 64; do
 ./run-xn-job.sh $i $nodelist
done
