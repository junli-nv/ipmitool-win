#!/bin/bash

pdsh -R ssh -f 100 -w $(cmsh -c 'device; list|grep dgx|grep UP'|awk '{print $2}'|paste -s -d',') <<- 'EOF'
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
systemctl restart lldpd
EOF

sleep 30

pdsh -R ssh -f 100 -w $(cmsh -c 'device; list|grep dgx|grep UP'|awk '{print $2}'|paste -s -d',') <<- 'EOF' | sort
lldpcli show neighbors | grep -E 'Interface:|SysName:|PortID:'|awk '/Interface:/{print $2} /SysName:/{print $NF} /PortID:/{print $NF}'|tr ',' ' '|paste - - -|sort|paste -s -d ' ' -|awk '{if(NF==6 && $3 != $6){print $0," <*>"}else{print $0}}'
EOF
