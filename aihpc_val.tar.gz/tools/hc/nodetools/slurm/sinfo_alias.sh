#!/bin/bash

alias msinfo='sinfo -o "%20U %100E %19H %10P %10L %10l %6T %15i %6D %N"'
