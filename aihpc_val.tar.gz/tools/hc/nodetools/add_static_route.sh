#!/bin/bash
#
route add -net 172.16.0.0/21 gw 172.16.15.254
route add -net 172.16.22.0/23 gw 172.16.15.254
route add -net 172.16.20.0/23 gw 172.16.15.254
