#!/bin/bash
#
#Ref:  https://docs.nvidia.com/dgx/dgxb200-user-guide/redfish-api-supp.html
#
topdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

source $topdir/passwd.sh
export hostlist=$topdir/hosts.list

query_hgx_bmc_log_dgx(){
  curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/HGX_Baseboard_0/LogServices/EventLog/Entries"|jq '.Members[]|.Created,.Severity,."CPER"."Oem"."Nvidia"."Nvidia"."Signature",.Message'|paste - - - -|tr -s '[:space:]'
}

clear_hgx_bmc_log_dgx(){
  curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST "https://${bmc_ip}/redfish/v1/Systems/HGX_Baseboard_0/LogServices/EventLog/Actions/LogService.ClearLog"
}

query_sys_bmc_log_dgx(){
  curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/DGX/LogServices/BIOS/Entries"|jq '.Members[]|.Created,.Severity,.Message'|paste - - -|tr -s '[:space:]'
}

clear_sys_bmc_log_dgx(){
  curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST "https://${bmc_ip}/redfish/v1/Systems/DGX/LogServices/EventLog/Actions/LogService.ClearLog"
}

query_dgx_macs(){
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - -|grep IPv4 \
  |sed -e 's:/MAC:"MAC:g' -e 's:/IPv4:"IPv4:g'|awk -F'"' '{print $2, $7, $6}'|while read boot macA busB
  do
    echo OS ${boot} $(echo ${macA}|cut -c5-16|sed 's/../&:/g'|cut -c 1-17) ${busB}
  done
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Managers/BMC/EthernetInterfaces|jq '.Members[]."@odata.id"'|tr -d '"'|while read i
  do
    curl -s -k -u $bmc_username:$bmc_password "https://${bmc_ip}$i"|jq '.Id,.MACAddress' | paste - - | tr -s ' ' | xargs -I {} echo BMC {}
  done
}

query_dgx_bootorder(){
  tmpf=$(mktemp)
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - - > $tmpf
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX?\$select=Boot/BootOrder|jq -r '.Boot.BootOrder[]'|while read i; do
    grep -w ${i##Boot} $tmpf
  done
  rm -f $tmpf
}

network_boot_dgx(){
  echo "INFO: power off node"
  task_id=$(curl -s -k -u $bmc_username:$bmc_password -X POST -H 'Content-Type: application/json' https://$bmc_ip/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset -d '{"ResetType": "ForceOff"}'|jq -r .Id)
  ret=$(curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/TaskService/Tasks/${task_id}|jq -r .TaskState)
  while :; do if [ "X${ret}X" == "XRunningX" ]; then sleep 2; else break; fi; done && echo "INFO: done"
  #target_boots=($(curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX/BootOptions?\$expand=.|jq '.Members[]|.Name,.DisplayName,.UefiDevicePath'|paste - - -|grep Nvidia|grep -v USB|awk '{print $1}'))
  target_boots=($(curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX/BootOptions?\$expand=.|jq '.Members[]|.Name,.DisplayName,.UefiDevicePath'|paste - - -|grep 0x20|grep -v USB|awk '{print $1}'))
  all_pxev4_boots=($(curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX/BootOptions?\$expand=.|jq '.Members[]|.Name,.DisplayName'|paste - -|grep IPv4|awk '{print $1}'))
  pxev4_boots=(${target_boots[*]} $(echo ${all_pxev4_boots[*]} ${target_boots[*]}|tr ' ' '\n'|sort|uniq -c|grep -v -w ' 2 '|awk '{print $NF}'))

  old_boots=($(curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX?\$select=Boot/BootOrder|jq '.Boot.BootOrder[]'))
  pad_boots=($(echo ${pxev4_boots[*]} ${old_boots[*]}|tr ' ' '\n'|sort|uniq -c|grep -v -w ' 2 '|awk '{print $NF}'))
  new_boots=$(echo ${pxev4_boots[*]} ${pad_boots[*]}|tr -s ' ' ',')
  echo OLD_BOOT_ORDER=${old_boots[*]}|tr ' ' ','
  echo NEW_BOOT_ORDER=$new_boots
  curl -s -k -u $bmc_username:$bmc_password  -H 'Content-Type: application/json' -H 'If-None-Match: "123456"' -X PATCH https://$bmc_ip/redfish/v1/Systems/DGX/SD -d "{\"Boot\":{\"BootOrder\": [${new_boots}]}}"|jq
  echo "INFO: The following boot order applied"
  curl -s -k -u $bmc_username:$bmc_password  -H 'Content-Type: application/json'  https://$bmc_ip/redfish/v1/Systems/DGX/SD | jq '.Boot.BootOrder[]'|paste -s -d','
  ipmitool -I lanplus -H ${bmc_ip} -U ${bmc_username} -P ${bmc_password} chassis bootdev pxe options=persistent
  echo "reboot node"; sleep 1
  task_id=$(curl -s -k -u $bmc_username:$bmc_password -X POST -H 'Content-Type: application/json' https://$bmc_ip/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset -d '{"ResetType": "On"}'|jq -r .Id)
  ret=$(curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/TaskService/Tasks/${task_id}|jq -r .TaskState)
  while :; do if [ "X${ret}X" == "XRunningX" ]; then sleep 2; else break; fi; done && echo "INFO: done"
}

sensors(){
curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/TelemetryService/MetricReports|jq '.Members[]."@odata.id"'|tr -d '"'|grep -v NvidiaNMMetrics_0|while read i; do
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '.MetricValues[]|[.Timestamp,.MetricProperty,.MetricValue]|@tsv' | column -t | xargs -I {} echo "${i##*/} {}"
done
}

query_gpu_uuid_sn(){
curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/HGX_Baseboard_0/Processors|jq -r '.Members[]."@odata.id"'|grep GPU_|while read i; do echo ${i##*/} $(curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq '.UUID,.SerialNumber,.PartNumber'|paste -s -d' '); done
}

query_firmware(){
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/UpdateService/FirmwareInventory|jq -r '.Oem.Ami.FirmwareInventory[]|[.Name,.Version]|@tsv'|column -t
#curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/UpdateService/FirmwareInventory|jq '.Members[]."@odata.id"'|tr -d '"'|while read i; do
#  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '[.Id,.Version]|@tsv'|column -t
#done
}

power_ac_cycle(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType":"AuxPowerCycleForce"}' \
  https://${bmc_ip}/redfish/v1/Chassis/BMC/Actions/Oem/NvidiaChassis.AuxPowerReset
}

power_graceful_shutdown(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "GracefulShutdown"}' \
  https://${bmc_ip}/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset
}

power_force_off(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceOff"}' \
  https://${bmc_ip}/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset
}

power_on(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "On"}' \
  https://${bmc_ip}/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset
}

power_cycle(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "PowerCycle"}' \
  https://${bmc_ip}/redfish/v1/Systems/DGX/Actions/ComputerSystem.Reset
}

power_status(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  https://${bmc_ip}/redfish/v1/Systems/DGX|jq '.PowerState'
}

hmc_graceful_restart(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "GracefulRestart"}' \
  https://${bmc_ip}/redfish/v1/Managers/HGX_BMC/Actions/Manager.Reset
}

hmc_force_restart(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceRestart"}' \
  https://${bmc_ip}/redfish/v1/Managers/HGX_BMC/Actions/Manager.Reset
}

bmc_restart(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceRestart", "Description": "BMC bundle update curl"}' \
  https://${bmc_ip}/redfish/v1/Managers/BMC/Actions/Manager.Reset
}

add_user(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -H "Content-Type: application/json" \
  -X POST \
  -d '{"UserName": "supperuser", "Password": "P@ss$1234", "RoleId": "Operator"}' \
  https://${bmc_ip}/redfish/v1/AccountService/Accounts
}

update_passwd(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -H "Content-Type: application/json" \
  https://${bmc_ip}/redfish/v1/AccountService/Accounts/${bmc_username} \
  --data '{ "Attributes": { "Password": "NEW_PASSWORD" } }'
}

enable_ipmi(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X PATCH \
  -d '{ "IPMI": {"ProtocolEnabled": true} }' \
  https://${bmc_ip}/redfish/v1/Managers/BMC/NetworkProtocol
}

check_ipmi(){
  curl -k -s --user "${bmc_username}:${bmc_password}" \
  https://${bmc_ip}/redfish/v1/Managers/BMC/NetworkProtocol | jq '.IPMI'
}

get_serial_number(){
(
curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/DGX|jq -r '.Id,.SerialNumber'|paste - -
curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Chassis|jq -r '.Members[]."@odata.id"'|grep HGX_ProcessorModule|while read i; do
  curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '.Id,.PartNumber,.SerialNumber'|paste - - -
done
)| paste -s -d ','
}

get_task_status(){
curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/TaskService/Tasks|jq -r '.Members[]."@odata.id"'|while read i; do
curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}${i}|jq -r '[.Id,.Description,.StartTime,.EndTime,.TaskState]|@tsv'
done
}
