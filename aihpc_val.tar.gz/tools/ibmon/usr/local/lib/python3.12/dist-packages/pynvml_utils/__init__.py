from .smi import nvidia_smi

__version__ = '12.0.0'
